package com.bank.ui;

import com.bank.bean.Customer;
import com.bank.exceprtion.CustomerNotFound;
import com.bank.service.ServiceImp;

import java.util.Scanner;

public class UserIn {
	static ServiceImp service = new ServiceImp();

	static Customer bean = new Customer();
	static Scanner sc;

	public static void main(String[] args) throws CustomerNotFound {
		// TODO Auto-generated method stub
		
		int a=1;
		while (a==1) {
			System.out.println("WELCOME");
			System.out.println("*******************************");
			System.out.println("-------------------------------");
			System.out.println("********************************");
			System.out.println("SELECT YOUR CHOICE");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.WITHDRAW");
			System.out.println("3.DEPOSIT");
			System.out.println("4.SHOW BALANCE");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTION");
			System.out.println("7.EXIT");
			System.out.println("*******************************");
			System.out.println("-------------------------------");
			System.out.println("********************************");


			sc = new Scanner(System.in);

			int choice = sc.nextInt();

			bean.getCurrBal();

			switch (choice) {


			case 1:
				boolean validname=false;
				boolean validphno=false;
				boolean validage=false;
				boolean validpan=false;
				boolean validateemail=false;
				do{					
					System.out.println("ENTER CUSTOMER NAME");
					String cname = sc.next();

					bean.setName(cname);

					validname=service.validateName(cname);
					if(validname)
					{			
						do {				
							System.out.println("ENTER CUSTOMER MOBILENO");
							String mobileno = sc.next();
							bean.setMobileno(mobileno);
							if( validphno=service.validatePhno(mobileno))
							{									
								do {	
									System.out.println("ENTER CUSTOMER PANNO");
									String panno = sc.next().toUpperCase();
									bean.setPanno(panno);
									if(validpan=service.validatePan(panno))
									{				 


										do {			
											System.out.println("ENTER CUSTOMER AGE");
											int age = sc.nextInt();
											bean.setAge(age);
											if(validage=service.validateAge(age))
											{

												System.out.println("ENTER CUSTOMER ADDR");
												StringBuffer addr = new StringBuffer();
												System.out.println("ENTER HOUSE NO");
												StringBuffer addr1 = new StringBuffer();
												//String s = addr.next();
												//addr.append(sc.next());
												addr1.append(sc.next());
												System.out.println("ENTER STREET NAME");
												StringBuffer addr2 = new StringBuffer();
												addr2.append(sc.next());
												System.out.println("ENTER CITY NAME");
												StringBuffer addr3 = new StringBuffer();
												addr3.append(sc.next());
												System.out.println("ENTER STATE NAME");
												StringBuffer addr4 = new StringBuffer();
												addr4.append(sc.next());
												System.out.println("ENTER PINCODE");
												StringBuffer addr5 = new StringBuffer();
												addr5.append(sc.next());			
												addr.append(","+addr1).append(","+addr2).append(","+addr3).append(","+addr4);	
												bean.setAddress(addr);

												do
												{
													System.out.println("ENTER EMAIL ID");
													String email=sc.next();
													bean.setEmailId(email);

													validateemail=service.validateMail(email);
													if(validateemail)
													{
														int accNumber=(int)((Math.random()*40000)+10000); 
														int pin=(int)((Math.random()*100)+1000); 
														bean.setAccNumber(accNumber);
														bean.setPin(pin);
														boolean isAdded = service.addCustomer(bean);
														if (validname && validphno && isAdded && validage && validpan &&validateemail) 
														{
															System.out.println("added successfully");
															System.out.println(bean);
														} else
															System.out.println("not added");

													}
													else 
														System.out.println("ENTER CORRECT EMAIL...");
												}while(!validateemail);
											}else
												System.out.println("ENTER CORRECT AGE----");
										}while(!validage);
									}else
										System.out.println("ENTER CORRECT PANNO----");
								}while(!validpan);
							}else
								System.out.println("ENTER CORRECT MOBILE NUMBER----");
						}while(!validphno);
					}else
					{
						System.out.println("ENTER CORRECT NAME FORMAT----");
					}
				}while(!validname);			
				break;


			case 2:

				System.out.println("WITHDRAW");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				int accNumber = sc.nextInt();
				System.out.println("ENTER THE PIN");
				int pin = sc.nextInt();
				boolean verifyDe=service.verifyDetails(email,accNumber, pin);
				if(verifyDe)
				{
				System.out.println("ENTER THE AMOUNT TO WITHDRAW");
				double withdraw = sc.nextDouble();
				boolean validateAmount = service.validateAmount(withdraw);
				if (validateAmount) {
				Boolean withdrawn=withdraw(accNumber,withdraw);
				if(withdrawn)
				{
					System.out.println("THE WITHDRAWN AMOUNT IS"+withdraw);
					
				}
				else
				{
					try
					{
						throw new CustomerNotFound("WITHDRAW FAILED");

					}
					catch(CustomerNotFound e)
					{
						System.out.println(e.getMessage());
					}
					
				}
				}
				else
				{
					try
					{
						throw new CustomerNotFound("THE AMOUNT SHOULD BE NUMBERS ONLY");

					}
					catch(CustomerNotFound e)
					{
						System.out.println(e.getMessage());
					}
				}
				}
				 else
					{
						try
						{
							throw new CustomerNotFound("ENTER THE VALID EMAILID,ACCNO AND PIN");

						}
						catch(CustomerNotFound e)
						{
							System.out.println(e.getMessage());
						}
					}
				
				/*boolean valid = service.validAccountNo(email, accNumber, pin);
				if (valid) {
					Customer a=service.displayCust(accNumber);
					System.out.println("ENTER THE AMOUNT TO WITHDRAW");
					int withdraw = sc.nextInt();
					boolean validateAmount = service.validatedeposit(withdraw);

					if (validateAmount) {

						int withdrawresult = service.withDraw(a, withdraw);
						System.out.println("WITHDRAW SUCCESS FULL!!!");
						System.out.println("WITHDRAWN AMOUNT IS"+withdraw);
						System.out.println(" AVAILABLE BALANCE IS:" + withdrawresult);
					} else
					{
						try
						{
							throw new CustomerNotFound("THE AMOUNT SHOULD BE NUMBERS ONLY");

						}
						catch(CustomerNotFound e)
						{
							System.out.println(e.getMessage());
						}
					}

				} else
				{
					try
					{
						throw new CustomerNotFound("ENTER THE VALID EMAILID,ACCNO AND PASSWORD");

					}
					catch(CustomerNotFound e)
					{
						System.out.println(e.getMessage());
					}
				}
*/
				break;

		case 3:
				System.out.println("DEPOSIT");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email2 = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				int accNumber2 = sc.nextInt();
				System.out.println("ENTER THE PIN");
				int pin2 = sc.nextInt();
				boolean verifyDe1=service.verifyDetails(email2,accNumber2, pin2);
				if(verifyDe1)
				{
				System.out.println("ENTER THE AMOUNT TO DEPOSIT");
				double deposit = sc.nextDouble();
				
				deposit(accNumber2,deposit);
				System.out.println("the deposited amount is"+deposit);
				}
				else
				{
					try
					{
						throw new CustomerNotFound("ENTER THE VALID EMAILID,ACCNO AND PASSWORD");

					}
					catch(CustomerNotFound e)
					{
						System.out.println(e.getMessage());
					}
				}
				
	             break;
			case 4:
				System.out.println("SHOW BALANCE");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email1 = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				int accNumber1 = sc.nextInt();
				System.out.println("ENTER THE PIN");
				int pin1 = sc.nextInt();
				boolean validate=service.verifyDetails(email1, accNumber1, pin1);
				if(validate)
				{
					Double balanc=showBalance(accNumber1);
					System.out.println("THE AVAILABLE BALANCE IS"+balanc);
				}
				else
				{
					try
					{
						throw new CustomerNotFound("ENTER THE VALID EMAILID,ACCNO AND PASSWORD");

					}
					catch(CustomerNotFound e)
					{
						System.out.println(e.getMessage());
					}
				}
				
				/*boolean valid2 = service.validAccountNo(email1, accNumber1, pin1);
				if (valid2) {
					Customer a=service.displayCust(accNumber1);
					int balanceAmount = service.showBalance(a,accNumber1);
					System.out.println("Balance is" + balanceAmount);
				} else
					System.out.println("SORRY YOUR TRANSACTION IS CANCELLED!!!ENTER THE VALID DETAILS");*/
				break;
			case 5:
				System.out.println("FUND TRANSFER");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email3 = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				int accNumber3 = sc.nextInt();
				System.out.println("ENTER THE PIN");
				int pin3 = sc.nextInt();
				boolean validate1=service.verifyDetails(email3, accNumber3, pin3);
				if(validate1)
				{
					System.out.println("ENTER THE ACCOUNT NUMBER TO TRANSFER");
					int accNumber4 = sc.nextInt();
					System.out.println("ENTER THE EMAIL ID");
					String email4 = sc.next();
					boolean  verifyAccno=verifyAccno(accNumber4,email4);
					if(verifyAccno)
					{
						System.out.println("ENTER THE AMOUNT TO TRANSFER");
					Double amount=sc.nextDouble();
						
						boolean fundTrans=fundTransfer(accNumber3,accNumber4,amount);
						if(fundTrans)
						{
							Double amCust1=showBalance(accNumber3);
							Double amCust2=showBalance(accNumber4);
							System.out.println("THE BALANCE OF CUSTOMER1:"+amCust1);
							System.out.println("THE BALANCE OF CUSTOMER2:"+amCust2);
						}
					}
						
				}
				/*boolean valid3 = service.validAccountNo(email3, accNumber3, pin3);
				if(valid3)
				{
					Customer a=service.displayCust(accNumber3);
					System.out.println("ENTER THE EMAIL ADDRESS TO TRANSFER");
					String email4 = sc.next();
					System.out.println("ENTER THE ACCUNT NUMBER TO TRANFER1");
					int accNumber4 = sc.nextInt();
				boolean valid4=service.verifyAcc(email4,accNumber4);
					if(valid4)
					{
						Customer b=service.displayCust(accNumber4);
						System.out.println("ENTER THE AMOUNT TO TRANSFER");
						int amount=sc.nextInt();
						boolean b1=service.fundTransfer(email3,accNumber3,pin3,a,b,email4,accNumber4,amount);
						if(b1){
							System.out.println("BALANCE IN YOUR ACCOUNT AFTER TRANSFER IS"+a.getCurrBal());
							System.out.println("BALANCE IN OTHER ACCOUNT IS"+b.getCurrBal());
						}else {
							try
							{
								throw new CustomerNotFound("SORRRY TRANSACTION FAILED!!!!");

							}
							catch(CustomerNotFound e)
							{
								System.out.println(e.getMessage());
							}

						}
					}
					else
					{

						try
						{
							throw new CustomerNotFound("ENTER THE VALID DETAILS TO TRANSFER");

						}
						catch(CustomerNotFound e)
						{
							System.out.println(e.getMessage());
						}



					}
				}
				else
				{
					try
					{
						throw new CustomerNotFound("PLEASE ENTER VALID DETAILS");

					}
					catch(CustomerNotFound e)
					{
						System.out.println(e.getMessage());
					}



				}
*/
				break;
			case 6:
				System.out.println("PRINT TRANSACTION");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email4 = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER");
				int accNumber4 = sc.nextInt();
				System.out.println("ENTER THE PIN");
				int pin4 = sc.nextInt();
				boolean validate2=service.verifyDetails(email4, accNumber4, pin4);
				if(validate2)
				{
					printTransaction(accNumber4);
				}
				break;
			case 7: System.exit(0);
			break;
			default:
				System.out.println("CHOOSE THE COREECT CHOICE");
				break;
			}

		}
	}

	private static boolean printTransaction(int accNumber4) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return service.printTransaction(accNumber4);
	}

	private static boolean fundTransfer(int accNumber3, int accNumber4,Double amount) throws CustomerNotFound
			 {
		// TODO Auto-generated method stub
		
		return service.fundTransfer(accNumber3,accNumber4,amount);
	}

	private static boolean verifyAccno(int accNumber4, String email4) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return service.verifyAccno(accNumber4,email4);
	}

	private static Double showBalance(int accNumber1) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return service.showBalance(accNumber1); 
	}

	private static boolean withdraw(int accNumber,
			double withdraw) throws CustomerNotFound {
		// TODO Auto-generated method stub
		
			return service.withdraw(accNumber,withdraw);
	
		
	}

	private static 	Boolean deposit( int accNumber2,double deposit) throws CustomerNotFound {
		
		return service.deposit(accNumber2,deposit);
		
		
	}

	private static void exit() {
		// TODO Auto-generated method stub

		System.out.println("THANK YOU FOR USING THIS BANK!!!!!!");
	}

}
